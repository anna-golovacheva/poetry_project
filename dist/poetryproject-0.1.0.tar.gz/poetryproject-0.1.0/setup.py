# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['poetryproject']

package_data = \
{'': ['*']}

install_requires = \
['datetime>=4.7,<5.0', 'regex>=2022.10.31,<2023.0.0']

entry_points = \
{'console_scripts': ['do_something = poetryproject.main:do_something']}

setup_kwargs = {
    'name': 'poetryproject',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '==3.8.10',
}


setup(**setup_kwargs)
